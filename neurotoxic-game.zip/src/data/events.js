// Re-export from the modularized structure
export { EVENTS_DB } from './events/index';
